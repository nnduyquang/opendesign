jQuery(document).ready(function() {
        $(function () {
            $('#defaultCountdown').countdown({until: new Date(2015, 8-1, 10, 8)}); // year, month, date, hour
        });
});		

